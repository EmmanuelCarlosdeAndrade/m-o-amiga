﻿using BibliotecaConsoleApp.Model;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;

namespace BibliotecaConsoleApp.DAO
{
    public class LivroDAO
    {
        public void Inserir(Livro livro)
        {
            using (SqlConnection conn = Database.GetConnection())
            {
                string sql = "INSERT INTO Livro (Titulo, Genero, AnoPublicacao, AutorId) VALUES (@Titulo, @Genero, @Ano, @AutorId)";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Titulo", livro.Titulo);
                cmd.Parameters.AddWithValue("@Genero", livro.Genero);
                cmd.Parameters.AddWithValue("@Ano", livro.AnoPublicacao);
                cmd.Parameters.AddWithValue("@AutorId", livro.AutorId);
                cmd.ExecuteNonQuery();
            }
        }

        public List<Livro> Listar()
        {
            List<Livro> livros = new List<Livro>();

            using (SqlConnection conn = Database.GetConnection())
            {
                string sql = @"
                    SELECT l.*, a.Nome AS NomeAutor, a.Nacionalidade AS NacionalidadeAutor
                    FROM Livro l
                    JOIN Autor a ON l.AutorId = a.Id";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    livros.Add(new Livro
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        Titulo = reader["Titulo"].ToString(),
                        Genero = reader["Genero"].ToString(),
                        AnoPublicacao = Convert.ToInt32(reader["AnoPublicacao"]),
                        AutorId = Convert.ToInt32(reader["AutorId"]),
                        NomeAutor = reader["NomeAutor"].ToString(),
                        NacionalidadeAutor = reader["NacionalidadeAutor"].ToString()
                    });
                }
            }

            return livros;
        }

        public void Editar(Livro livro)
        {
            using (SqlConnection conn = Database.GetConnection())
            {
                string sql = "UPDATE Livro SET Titulo = @Titulo, Genero = @Genero, AnoPublicacao = @Ano, AutorId = @AutorId WHERE Id = @Id";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Id", livro.Id);
                cmd.Parameters.AddWithValue("@Titulo", livro.Titulo);
                cmd.Parameters.AddWithValue("@Genero", livro.Genero);
                cmd.Parameters.AddWithValue("@Ano", livro.AnoPublicacao);
                cmd.Parameters.AddWithValue("@AutorId", livro.AutorId);
                cmd.ExecuteNonQuery();
            }
        }

        public void Remover(int id)
        {
            using (SqlConnection conn = Database.GetConnection())
            {
                string sql = "DELETE FROM Livro WHERE Id = @Id";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.ExecuteNonQuery();
            }
        }

        // ✅ Função de pesquisa por nome do livro ou autor:
        public List<Livro> PesquisarPorNomeOuAutor(string termo)
        {
            List<Livro> livros = new List<Livro>();

            using (SqlConnection connection = Database.GetConnection())
            {
                string query = @"
                    SELECT l.Id, l.Titulo, l.Genero, l.AnoPublicacao, l.AutorId, a.Nome AS NomeAutor
                    FROM Livro l
                    INNER JOIN Autor a ON l.AutorId = a.Id
                    WHERE l.Titulo LIKE @termo OR a.Nome LIKE @termo";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@termo", "%" + termo + "%");

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Livro livro = new Livro
                    {
                        Id = reader.GetInt32(0),
                        Titulo = reader.GetString(1),
                        Genero = reader.GetString(2),
                        AnoPublicacao = reader.GetInt32(3),
                        AutorId = reader.GetInt32(4),
                        NomeAutor = reader.GetString(5)
                    };

                    livros.Add(livro);
                }
            }

            return livros;
        }
    }
}
