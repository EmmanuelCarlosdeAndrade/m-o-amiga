﻿using BibliotecaConsoleApp.Service;
using BibliotecaConsoleApp.Model;
using System;

AutorService autorService = new AutorService();
LivroService livroService = new LivroService();

int opcao;
do
{
    Console.WriteLine("=== MENU ===");
    Console.WriteLine("1 - Inserir Autor");
    Console.WriteLine("2 - Listar Autores");
    Console.WriteLine("3 - Editar Autor");
    Console.WriteLine("4 - Remover Autor");
    Console.WriteLine("5 - Inserir Livro");
    Console.WriteLine("6 - Pesquisar Livro por Título ou Autor");
    Console.WriteLine("7 - Editar Livro");
    Console.WriteLine("8 - Remover Livro");
    Console.WriteLine("0 - Sair");
    Console.Write("Escolha uma opção: ");

    if (!int.TryParse(Console.ReadLine(), out opcao))
    {
        Console.WriteLine("Opção inválida. Tente novamente.\n");
        continue;
    }

    Console.Clear();

    try
    {
        switch (opcao)
        {
            case 1:
                Console.Write("Nome: ");
                string nome = Console.ReadLine();
                Console.Write("Nacionalidade: ");
                string nacionalidade = Console.ReadLine();
                autorService.CadastrarAutor(nome, nacionalidade);
                break;

            case 2:
                var autores = autorService.ObterTodosAutores();
                Console.WriteLine("=== Lista de Autores ===");
                foreach (var autor in autores)
                {
                    Console.WriteLine($"ID: {autor.Id} | Nome: {autor.Nome} | Nacionalidade: {autor.Nacionalidade}");
                }
                Console.WriteLine();
                break;

            case 3:
                Console.Write("ID do autor a editar: ");
                if (int.TryParse(Console.ReadLine(), out int idEditar))
                {
                    Console.Write("Novo Nome: ");
                    string novoNome = Console.ReadLine();
                    Console.Write("Nova Nacionalidade: ");
                    string novaNacionalidade = Console.ReadLine();
                    autorService.EditarAutor(idEditar, novoNome, novaNacionalidade);
                }
                else
                {
                    Console.WriteLine("ID inválido.");
                }
                break;

            case 4:
                Console.Write("ID do autor a remover: ");
                if (int.TryParse(Console.ReadLine(), out int idRemover))
                {
                    autorService.RemoverAutor(idRemover);
                }
                else
                {
                    Console.WriteLine("ID inválido.");
                }
                break;

            case 5:
                Console.Write("Título: ");
                string titulo = Console.ReadLine();
                Console.Write("Gênero: ");
                string genero = Console.ReadLine();
                Console.Write("Ano de Publicação: ");
                if (!int.TryParse(Console.ReadLine(), out int ano))
                {
                    Console.WriteLine("Ano inválido.");
                    break;
                }
                Console.Write("ID do Autor: ");
                if (!int.TryParse(Console.ReadLine(), out int autorId))
                {
                    Console.WriteLine("ID do autor inválido.");
                    break;
                }
                livroService.CadastrarLivro(titulo, genero, ano, autorId);
                break;

            case 6:
                Console.Write("Digite o nome do livro ou autor para buscar: ");
                string termoBusca = Console.ReadLine();
                var resultados = livroService.PesquisarLivros(termoBusca);

                if (resultados.Count == 0)
                {
                    Console.WriteLine("Nenhum resultado encontrado.");
                }
                else
                {
                    foreach (var livro in resultados)
                    {
                        Console.WriteLine($"ID: {livro.Id} | Título: {livro.Titulo} | Gênero: {livro.Genero} | Ano: {livro.AnoPublicacao} | Autor: {livro.NomeAutor}");
                    }
                }
                Console.WriteLine();
                break;

            case 7:
                Console.Write("ID do livro a editar: ");
                if (!int.TryParse(Console.ReadLine(), out int idLivroEditar))
                {
                    Console.WriteLine("ID inválido.");
                    break;
                }
                Console.Write("Novo Título: ");
                string novoTitulo = Console.ReadLine();
                Console.Write("Novo Gênero: ");
                string novoGenero = Console.ReadLine();
                Console.Write("Novo Ano: ");
                if (!int.TryParse(Console.ReadLine(), out int novoAno))
                {
                    Console.WriteLine("Ano inválido.");
                    break;
                }
                Console.Write("Novo ID do Autor: ");
                if (!int.TryParse(Console.ReadLine(), out int novoAutorId))
                {
                    Console.WriteLine("ID do autor inválido.");
                    break;
                }
                livroService.EditarLivro(idLivroEditar, novoTitulo, novoGenero, novoAno, novoAutorId);
                break;

            case 8:
                Console.Write("ID do livro a remover: ");
                if (int.TryParse(Console.ReadLine(), out int idLivroRemover))
                {
                    livroService.RemoverLivro(idLivroRemover);
                }
                else
                {
                    Console.WriteLine("ID inválido.");
                }
                break;

            case 0:
                Console.WriteLine("Saindo...");
                break;

            default:
                Console.WriteLine("Opção inválida.\n");
                break;
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Erro: {ex.Message}");
    }

} while (opcao != 0);
